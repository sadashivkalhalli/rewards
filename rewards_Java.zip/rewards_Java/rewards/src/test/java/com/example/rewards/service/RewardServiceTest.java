package com.example.rewards.service;

import static org.junit.jupiter.api.Assertions.assertFalse;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class RewardServiceTest {
	 @Test
	    void testRewardCalculation() {
	        RewardService service = new RewardService();
	        assertFalse(service.getRewardPointsPerCustomer().isEmpty());
	        assertFalse(service.getTotalRewardPoints().isEmpty());
	    }
}
