package com.example.rewards.model;

import jakarta.persistence.*;
import java.time.LocalDate;

/**
 * Represents a customer transaction.
 */
@Entity
@Table(name = "transactions")
public class Transaction {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	private Long customerId;
	private LocalDate date;
	private double amount;

	public Transaction() {
	}

	public Transaction(Long customerId, LocalDate date, double amount) {
		this.customerId = customerId;
		this.date = date;
		this.amount = amount;
	}

	public Long getId() {
		return id;
	}

	public Long getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Long customerId) {
		this.customerId = customerId;
	}

	public LocalDate getDate() {
		return date;
	}

	public void setDate(LocalDate date) {
		this.date = date;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}
}
