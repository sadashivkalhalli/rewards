package com.example.rewards.service;

import com.example.rewards.model.Transaction;
import com.example.rewards.repository.TransactionRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.YearMonth;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Service for calculating customer reward points.
 */
@Service
public class RewardService {
	RewardService() {
		this.transactionRepository = null;
	}

	@Autowired
	private final TransactionRepository transactionRepository;

	public RewardService(TransactionRepository transactionRepository) {
		this.transactionRepository = transactionRepository;
	}

	private int calculatePoints(double amount) {
		int points = 0;
		if (amount > 100) {
			points += (int) ((amount - 100) * 2);
			amount = 100;
		}
		if (amount > 50) {
			points += (int) ((amount - 50) * 1);
		}
		return points;
	}

	public final List<Transaction> transactions = List.of(new Transaction(1L, LocalDate.of(2024, 1, 10), 120),
			new Transaction(1L, LocalDate.of(2024, 1, 15), 80), new Transaction(2L, LocalDate.of(2024, 2, 20), 200),
			new Transaction(1L, LocalDate.of(2024, 2, 5), 150), new Transaction(2L, LocalDate.of(2024, 3, 5), 90));

	public Map<Long, Map<String, Integer>> getRewardPointsPerCustomer() {
		// List<Transaction> transactions = transactions;
		// List<Transaction> transactions=null;
		Map<Long, Map<String, Integer>> customerRewards = new HashMap<>();
		for (Transaction transaction : transactions) {
			int points = calculatePoints(transaction.getAmount());
			YearMonth yearMonth = YearMonth.from(transaction.getDate());
			customerRewards.computeIfAbsent(transaction.getCustomerId(), k -> new HashMap<>())
					.merge(yearMonth.toString(), points, Integer::sum);
		}
		return customerRewards;
	}

	public Map<Long, Integer> getTotalRewardPoints() {
		return getRewardPointsPerCustomer().entrySet().stream().collect(Collectors.toMap(Map.Entry::getKey,
				e -> e.getValue().values().stream().mapToInt(Integer::intValue).sum()));
	}
}
