package com.example.rewards.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.rewards.model.Transaction;
import com.example.rewards.repository.TransactionRepository;
import com.example.rewards.service.RewardService;

/**
 * REST Controller for reward points calculations.
 */
@RestController
@RequestMapping("api/rewards")
public class RewardsController {
	@Autowired
	private final RewardService rewardService;
	@Autowired
	private final TransactionRepository transactionRepository;

	public RewardsController(RewardService rewardService, TransactionRepository transactionRepository) {
		this.rewardService = rewardService;
		this.transactionRepository = transactionRepository;
	}

	/**
	 * Get monthly reward points per customer.
	 *
	 * @return Map of customer IDs to their reward points by month.
	 */
	@GetMapping("/monthly")
	public ResponseEntity<Map<Long, Map<String, Integer>>> getMonthlyRewards() {
		return ResponseEntity.ok(rewardService.getRewardPointsPerCustomer());
	}

	/**
	 * Get total reward points per customer.
	 *
	 * @return Map of customer IDs to their total reward points.
	 */
	@GetMapping("/total")
	public ResponseEntity<Map<Long, Integer>> getTotalRewards() {
		return ResponseEntity.ok(rewardService.getTotalRewardPoints());
	}

	/**
	 * Get all transactions.
	 *
	 * @return List of all transactions.
	 */
	@GetMapping("/transactions")
	public ResponseEntity<List<Transaction>> getAllTransactions() {
		return ResponseEntity.ok(transactionRepository.findAll());
	}

	/**
	 * Add a new transaction.
	 *
	 * @param transaction Transaction details
	 * @return Saved transaction
	 */
	@PostMapping("/transactions")
	public ResponseEntity<Transaction> addTransaction(@RequestBody Transaction transaction) {
		Transaction savedTransaction = (Transaction) transactionRepository.save(transaction);
		return ResponseEntity.status(HttpStatus.CREATED).body(savedTransaction);
	}

}
