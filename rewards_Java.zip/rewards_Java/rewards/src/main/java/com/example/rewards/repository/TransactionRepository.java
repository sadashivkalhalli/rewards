package com.example.rewards.repository;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.rewards.model.Transaction;

/**
 * Repository for managing customer transactions.
 */
@Repository
public interface TransactionRepository extends JpaRepository<Transaction, Long> {

	/**
	 * Finds transactions by customer ID.
	 *
	 * @param customerId the customer ID
	 * @return List of transactions for the given customer
	 */
	List<Transaction> findByCustomerId(Long customerId);

	public final List<Transaction> transactions = List.of(new Transaction(1L, LocalDate.of(2024, 1, 10), 120),
			new Transaction(1L, LocalDate.of(2024, 1, 15), 80), new Transaction(2L, LocalDate.of(2024, 2, 20), 200),
			new Transaction(1L, LocalDate.of(2024, 2, 5), 150), new Transaction(2L, LocalDate.of(2024, 3, 5), 90));

}
